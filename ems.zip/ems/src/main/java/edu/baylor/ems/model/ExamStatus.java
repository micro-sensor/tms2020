package edu.baylor.ems.model;

public enum ExamStatus {
    INIT, PROGRESS, DONE
}
