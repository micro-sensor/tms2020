package edu.baylor.ems.enums;

public enum QuestionTypeEnum {
    SELECT_ONE, SELECT_MANY, TEXT
}