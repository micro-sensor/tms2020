package edu.baylor.ems.model;

public class Configuration {
    private String name;

    public Configuration() {
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
